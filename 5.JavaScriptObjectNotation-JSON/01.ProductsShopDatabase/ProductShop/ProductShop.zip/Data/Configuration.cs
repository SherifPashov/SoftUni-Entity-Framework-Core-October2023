﻿namespace ProductShop.Data
{
    public static class Configuration
    {
        public const string ConnectionString =
            @"Server=DESKTOP-EC6KPVE\SQLEXPRESS;Database=ProductShop;Integrated Security=True";
    }
}
