﻿namespace Footballers.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-EC6KPVE\SQLEXPRESS;Database=FootballersExam;Trusted_Connection=True";
    }
}
