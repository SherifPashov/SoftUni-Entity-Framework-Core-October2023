﻿using Microsoft.EntityFrameworkCore;

namespace P01_StudentSystem.Data.Models;

//[Keyless]
public enum ContentType
{
    Application,
    Pdf,
    Zip
}