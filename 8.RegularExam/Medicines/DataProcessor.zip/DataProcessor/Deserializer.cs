﻿namespace Medicines.DataProcessor
{
    using Medicines.Data;
    using Medicines.Data.Models;
    using Medicines.Data.Models.Enums;
    using Medicines.DataProcessor.ImportDtos;
    using Microsoft.Extensions.Primitives;
    using Newtonsoft.Json;
    using ProductShop.Utilities;
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.Globalization;
    using System.Text;

    public class Deserializer
    {
        private const string ErrorMessage = "Invalid Data!";
        private const string SuccessfullyImportedPharmacy = "Successfully imported pharmacy - {0} with {1} medicines.";
        private const string SuccessfullyImportedPatient = "Successfully imported patient - {0} with {1} medicines.";

        public static string ImportPatients(MedicinesContext context, string jsonString)
        {
            StringBuilder sb = new StringBuilder();
            var patientsDto = JsonConvert.DeserializeObject<ImportPatientDto[]>(jsonString);

            var patientsValid = new List<Patient>();

            foreach (var pDto in patientsDto)
            {
                if (!IsValid(pDto))
                {
                    sb.AppendLine(ErrorMessage);
                    continue;
                }
                if (!(Enum.TryParse(pDto.AgeGroup, out AgeGroup ageGroup)))
                {
                    sb.AppendLine(ErrorMessage);
                    continue;
                }
                if (!(Enum.TryParse(pDto.Gender, out Gender gender)))
                {
                    sb.AppendLine(ErrorMessage);
                    continue;
                }

                var patient = new Patient()
                {
                    FullName = pDto.FullName,
                    AgeGroup = (AgeGroup)Enum.Parse(typeof(AgeGroup), pDto.AgeGroup),
                    Gender = (Gender)Enum.Parse(typeof(Gender), pDto.Gender),

                };
                foreach (var medicinesId in pDto.Madicines)
                {
                    if (patient.PatientsMedicines.Any(pm=>pm.MedicineId==medicinesId))
                    {
                        sb.AppendLine(ErrorMessage); 
                        continue;
                    }
                    patient.PatientsMedicines
                        .Add(new PatientMedicine()
                        {
                            MedicineId = medicinesId,
                        });
                }

                sb.AppendLine(String.Format(SuccessfullyImportedPatient, patient.FullName, patient.PatientsMedicines.Count()));
                patientsValid.Add(patient);
            }

            context.AddRange(patientsValid);
            context.SaveChanges();

            return sb.ToString().TrimEnd();

        }

        public static string ImportPharmacies(MedicinesContext context, string xmlString)
        {
            StringBuilder sb = new StringBuilder();
            var XmlParser = new XmlParser();

            ImportPharmacyDto[] pharmaciesDtos = XmlParser.Deserialize<ImportPharmacyDto[]>(xmlString, "Pharmacies");

            var pharmaciesValid = new List<Pharmacy>();


            foreach (var pharDto in pharmaciesDtos)
            {
                if (!IsValid(pharDto))
                {
                    sb.AppendLine(ErrorMessage);
                    continue;

                }
                if ((pharDto.IsNonStop != "true" || pharDto.IsNonStop != "false"))
                {
                    sb.AppendLine(ErrorMessage);
                    continue;
                }
                Pharmacy pharmacy = new Pharmacy()
                {
                    Name = pharDto.Name,
                    PhoneNumber = pharDto.PhoneNumber,
                    IsNonStop = bool.Parse(pharDto.IsNonStop)
                };

                foreach (var medDto in pharDto.Medicines)
                {
                    if (!IsValid(medDto))
                    {
                        sb.AppendLine(ErrorMessage);
                        continue;
                    }

                    DateTime productionDate = DateTime.ParseExact(medDto.ProductionDate, "yyyy-MM-dd", CultureInfo.InvariantCulture);
                    DateTime expiryDate = DateTime.ParseExact(medDto.ExpiryDate, "yyyy-MM-dd", CultureInfo.InvariantCulture);

                    if (productionDate <= expiryDate)
                    {
                        sb.AppendLine(ErrorMessage);
                        continue;
                    }

                    Medicine medicine = new Medicine()
                    {
                        Name = medDto.Name,
                        Price = medDto.Price,
                        ProductionDate = productionDate,
                        ExpiryDate = expiryDate,
                        Producer = medDto.Producer

                    };
                    if (pharDto.Medicines.Any(m => m.Name == medicine.Name 
                    && m.Producer == medicine.Producer))
                    {
                        sb.Append(ErrorMessage);
                        continue;
                    }
                    pharDto.Medicines.Append(medDto);
                }

                pharmaciesValid.Add(pharmacy);
                sb.AppendLine(String.Format(SuccessfullyImportedPharmacy,pharmacy.Name,pharmacy.Medicines.Count()));
            }

            context.AddRange(pharmaciesValid);
            context.SaveChanges();

            return sb.ToString().TrimEnd();
        }

        private static bool IsValid(object dto)
        {
            var validationContext = new ValidationContext(dto);
            var validationResult = new List<ValidationResult>();

            return Validator.TryValidateObject(dto, validationContext, validationResult, true);
        }
    }
}
