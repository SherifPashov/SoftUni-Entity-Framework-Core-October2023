﻿namespace MusicHub.Data
{
    public static class Configuration
    {
        public static string ConnectionString =
            @"Server=DESKTOP-EC6KPVE\SQLEXPRESS;Database=MusicHub;Trusted_Connection=True";
    }
}
